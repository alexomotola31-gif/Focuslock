p4.b
